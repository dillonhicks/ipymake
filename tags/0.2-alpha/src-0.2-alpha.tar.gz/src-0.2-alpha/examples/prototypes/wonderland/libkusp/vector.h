/** @file */

#ifndef _KUSP_VECTOR_H_
#define _KUSP_VECTOR_H_

int vector_insert(void ***arrayptr, int *sizeptr, void *item, int index);

#endif
