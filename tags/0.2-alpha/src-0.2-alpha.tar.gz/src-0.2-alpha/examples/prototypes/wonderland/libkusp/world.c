
int potato(void){
  
  return 20;

}
