#define PACKAGE_VERSION  "1.0"
#define PACKAGE_NAME "KUSP"
#define PREFIX  "/tmp/kusp-install"

