
clean_clksync:
    rm -rfv $IPYM_BINARY_DIR

all:
    print 'COMMON!'
    pass
