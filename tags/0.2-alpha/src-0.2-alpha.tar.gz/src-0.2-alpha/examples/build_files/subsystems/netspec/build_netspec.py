
clean_netspec:
    rm -rfv $IPYM_BINARY_DIR

all:
    print 'COMMON!'
    pass
